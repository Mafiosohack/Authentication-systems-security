# System 4 — OAuth 2.0 / OpenID Connect

Authentication Security Study Series. Methodology: **vulnerable → live attacks → hardened**.

Standards basis: RFC 6749, RFC 6750, RFC 7636, **RFC 9700** (OAuth 2.0 Security BCP, Jan 2025),
OpenID Connect Core 1.0. OAuth 2.1 is still an IETF draft and is treated as forward guidance only.

## Layout

```
oauth_engine.py        from-scratch primitives: codes, tokens, PKCE, hand-built JWT
launch.py              test harness: starts/stops a stack of servers
vulnerable/            auth_server.py (5000) + client_app.py (5001) + resource_server.py (5002)
hardened/              same three servers, RFC 9700 controls applied (same ports)
attacks/               attack1..attack5, standalone, each exposes attack() -> (ok, detail)
build_report.js        generates the Word report
System4_OAuth_OIDC_Report.docx
```

The vulnerable and hardened stacks use the **same ports** and never run at once — the harness
tears one down before starting the other. That is deliberate: it lets the fixed attack scripts hit
both stacks unchanged, so each control blocks its attack by its *intended* mechanism rather than by
an incidental redirect-URI mismatch.

## Seeded data (both stacks)

- Users: `alice`/`alicepw` (victim), `mallory`/`mallorypw` (attacker)
- Clients: `webapp` (confidential, secret `webapp-secret-0xDEADBEEF`) and `spa` (public, no secret)

## Run the engine self-test

```bash
python3 oauth_engine.py        # -> oauth_engine self-test OK
```

## Run the attacks against the vulnerable stack

```python
# from /home/claude/system4_oauth
import importlib, os
from launch import servers
import sys; sys.path += ["attacks"]
V = "vulnerable"
specs = [("as",f"{V}/auth_server.py",5000),("client",f"{V}/client_app.py",5001),("rs",f"{V}/resource_server.py",5002)]
with servers(specs):
    for m in ["attack1_redirect_uri","attack2_csrf_state","attack3_pkce","attack4_code_replay","attack5_idtoken"]:
        ok, detail = importlib.import_module(m).attack()
        print(("VULNERABLE " if ok else "BLOCKED ") + m + ": " + detail)
```

Point the same loop at `hardened/` (ports unchanged) to confirm every attack is blocked.

## The five vulnerabilities

| # | Flaw | Control (RFC 9700) |
|---|------|--------------------|
| 1 | redirect_uri not validated | exact-string match against registration (§2.1/§4.1) |
| 2 | no `state` | state bound to user-agent session (RFC 6749 §10.12, §4.7) |
| 3 | no PKCE | code_challenge required + verified (RFC 7636, §2.1.1) |
| 4 | code replayable | single-use codes + reuse revocation (§4.5) |
| 5 | id_token not verified | strict verify: pin alg, check sig/iss/aud/nonce (OIDC Core §3.1.3.7) |

## Regenerate the report

```bash
npm install docx
node build_report.js
python3 /mnt/skills/public/docx/scripts/office/validate.py System4_OAuth_OIDC_Report.docx
```

## Scope boundary with System 5

The OIDC id_token is a JWT. System 4 stops at the **validation policy** (does the client verify it
at all). System 5 attacks the token cryptography itself: RS256→HS256 algorithm confusion, `none`
against non-pinning libraries, weak-secret brute force, JWKS spoofing. The strict verifier built
here is System 5's defensive baseline. Implicit grant and DPoP/refresh-token rotation are noted but
not built.
