#!/usr/bin/env python3
"""Verify the hardened API: legitimate DPoP flow works, all five attacks fail.
Uses FastAPI's in-process TestClient (no socket)."""
import base64, hashlib, json, time, uuid
import jwt
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.asymmetric.ec import SECP256R1
from fastapi.testclient import TestClient

from hardened_jwt_api import app, PUBLIC_KEY
from cryptography.hazmat.primitives import serialization

c = TestClient(app)
BASE = "http://testserver"


def b64url(b): return base64.urlsafe_b64encode(b).rstrip(b"=").decode()


def new_key(): return ec.generate_private_key(SECP256R1())


def jwk_of(key):
    n = key.public_key().public_numbers()
    return {"kty": "EC", "crv": "P-256",
            "x": b64url(n.x.to_bytes(32, "big")),
            "y": b64url(n.y.to_bytes(32, "big"))}


def proof(key, htm, htu, token=None):
    payload = {"htm": htm, "htu": htu, "jti": uuid.uuid4().hex,
               "iat": int(time.time())}
    if token is not None:
        payload["ath"] = b64url(hashlib.sha256(token.encode()).digest())
    return jwt.encode(payload, key, algorithm="ES256",
                      headers={"typ": "dpop+jwt", "jwk": jwk_of(key)})


def ok(label, cond):
    print(f"    {'[PASS]' if cond else '[FAIL]'} {label}")


print("=" * 70)
print("LEGITIMATE DPoP FLOW")
print("=" * 70)
k = new_key()
r = c.post("/login", json={"username": "alice", "password": "password123"},
           headers={"dpop": proof(k, "POST", f"{BASE}/login")})
ok("login succeeds with DPoP proof", r.status_code == 200)
access = r.json()["access_token"]
refresh = r.json()["refresh_token"]

r = c.get("/api/profile", headers={"authorization": f"DPoP {access}",
          "dpop": proof(k, "GET", f"{BASE}/api/profile", token=access)})
ok("profile reachable with bound token + proof", r.status_code == 200)
ok("no PII in token (only sub/role returned)",
   set(r.json().keys()) == {"sub", "role"})

r = c.get("/api/admin", headers={"authorization": f"DPoP {access}",
          "dpop": proof(k, "GET", f"{BASE}/api/admin", token=access)})
ok("alice denied admin (role enforced)", r.status_code == 403)

print("\n" + "=" * 70)
print("V3 DEFENSE - refresh rotation + reuse detection (RFC 9700)")
print("=" * 70)
r = c.post("/refresh", headers={"refresh-token": refresh,
           "dpop": proof(k, "POST", f"{BASE}/refresh")})
ok("refresh rotates -> new tokens issued", r.status_code == 200)
new_refresh = r.json()["refresh_token"]
ok("rotated refresh token differs from original", new_refresh != refresh)
# Replay the ORIGINAL (now-spent) refresh token: theft signal.
r = c.post("/refresh", headers={"refresh-token": refresh,
           "dpop": proof(k, "POST", f"{BASE}/refresh")})
ok("replay of spent refresh -> 401 family revoked", r.status_code == 401)
print("        server said:", r.json()["detail"])
# The rotated token is now also dead because the whole family was burned.
r = c.post("/refresh", headers={"refresh-token": new_refresh,
           "dpop": proof(k, "POST", f"{BASE}/refresh")})
ok("rotated token also dead (family burned)", r.status_code == 401)

print("\n" + "=" * 70)
print("V4 DEFENSE - real revocation on logout")
print("=" * 70)
k2 = new_key()
r = c.post("/login", json={"username": "alice", "password": "password123"},
           headers={"dpop": proof(k2, "POST", f"{BASE}/login")})
access2 = r.json()["access_token"]
stolen = access2  # attacker grabs a copy
r = c.post("/logout", headers={"authorization": f"DPoP {access2}",
           "dpop": proof(k2, "POST", f"{BASE}/logout", token=access2)})
ok("logout succeeds", r.status_code == 200)
r = c.get("/api/profile", headers={"authorization": f"DPoP {stolen}",
          "dpop": proof(k2, "GET", f"{BASE}/api/profile", token=stolen)})
ok("token rejected AFTER logout -> 401 revoked", r.status_code == 401)
print("        server said:", r.json()["detail"])

print("\n" + "=" * 70)
print("V1 DEFENSE - algorithm confusion (alg=none / RS256->HS256)")
print("=" * 70)
forged = {"sub": "alice", "role": "admin", "typ": "access", "iss":
          "https://auth.system5.local", "aud": "system5-api",
          "iat": int(time.time()), "exp": int(time.time()) + 999,
          "ver": 1, "cnf": {"jkt": "x"}, "jti": "x"}
none_tok = b64url(json.dumps({"alg": "none", "typ": "JWT"}).encode()) + "." + \
    b64url(json.dumps(forged).encode()) + "."
r = c.get("/api/admin", headers={"authorization": f"DPoP {none_tok}",
          "dpop": proof(new_key(), "GET", f"{BASE}/api/admin", token=none_tok)})
ok("alg=none forgery rejected -> 401", r.status_code == 401)
pem = PUBLIC_KEY.public_bytes(serialization.Encoding.PEM,
      serialization.PublicFormat.SubjectPublicKeyInfo)
hdr = b64url(json.dumps({"alg": "HS256", "typ": "JWT"}).encode())
pl = b64url(json.dumps(forged).encode())
import hmac
sig = b64url(hmac.new(pem, f"{hdr}.{pl}".encode(), hashlib.sha256).digest())
hs_tok = f"{hdr}.{pl}.{sig}"
r = c.get("/api/admin", headers={"authorization": f"DPoP {hs_tok}",
          "dpop": proof(new_key(), "GET", f"{BASE}/api/admin", token=hs_tok)})
ok("RS256->HS256 forgery rejected -> 401", r.status_code == 401)

print("\n" + "=" * 70)
print("V5 DEFENSE - bearer replay by a different client (DPoP)")
print("=" * 70)
kv = new_key()
r = c.post("/login", json={"username": "admin", "password": "supersecret"},
           headers={"dpop": proof(kv, "POST", f"{BASE}/login")})
victim_token = r.json()["access_token"]
# Attacker has the token but NOT the victim's private key. They use their own.
katt = new_key()
r = c.get("/api/admin", headers={"authorization": f"DPoP {victim_token}",
          "dpop": proof(katt, "GET", f"{BASE}/api/admin", token=victim_token)})
ok("stolen token + attacker's own key rejected -> 401", r.status_code == 401)
print("        server said:", r.json()["detail"])
# And the legitimate holder still works.
r = c.get("/api/admin", headers={"authorization": f"DPoP {victim_token}",
          "dpop": proof(kv, "GET", f"{BASE}/api/admin", token=victim_token)})
ok("legitimate key still works", r.status_code == 200)

print("\n=== hardened verification complete ===")
