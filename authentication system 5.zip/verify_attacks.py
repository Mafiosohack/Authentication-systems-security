#!/usr/bin/env python3
"""Verify the attack scripts WITHOUT a live socket.

The sandbox kills lingering servers, so instead of binding a port we monkeypatch
`requests` to dispatch into Flask's in-process test client. The actual attack_*.py
files run unmodified; only their transport changes.
"""
import sys, importlib.util, traceback
from urllib.parse import urlsplit
import requests

from vulnerable_jwt_api import app
_client = app.test_client()


class _Resp:
    def __init__(self, tr):
        self._tr = tr
        self.status_code = tr.status_code
        self.content = tr.data
    def json(self):
        return self._tr.get_json(force=True)
    @property
    def text(self):
        return self._tr.get_data(as_text=True)


def _path(url):
    s = urlsplit(url)
    return s.path + (("?" + s.query) if s.query else "")


def _get(url, headers=None, **kw):
    return _Resp(_client.get(_path(url), headers=headers or {}))


def _post(url, json=None, headers=None, **kw):
    return _Resp(_client.post(_path(url), json=json, headers=headers or {}))


class _Session:
    def __init__(self):
        self.headers = {}
    def get(self, url, headers=None, **kw):
        return _Resp(_client.get(_path(url), headers={**self.headers, **(headers or {})}))
    def post(self, url, json=None, headers=None, **kw):
        return _Resp(_client.post(_path(url), json=json, headers={**self.headers, **(headers or {})}))


requests.get = _get
requests.post = _post
requests.Session = _Session

ATTACKS = [
    "attack_alg_confusion",
    "attack_refresh_no_rotation",
    "attack_no_revocation",
    "attack_no_expiry",
    "attack_bearer_replay",
]

for name in ATTACKS:
    print(f"\n{'#'*22} {name} {'#'*22}", flush=True)
    try:
        spec = importlib.util.spec_from_file_location(name, f"{name}.py")
        mod = importlib.util.module_from_spec(spec)
        # ensure the attack module sees our patched requests
        mod_requests = requests
        spec.loader.exec_module(mod)
        mod.requests = requests
        mod.main()
    except Exception:
        print(f"[!] {name} raised:", flush=True)
        traceback.print_exc()

print("\n=== verification complete ===", flush=True)
